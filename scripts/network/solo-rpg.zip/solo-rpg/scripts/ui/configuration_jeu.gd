extends Control

@onready var form_container: VBoxContainer = $VBoxContainer/FormContainer
@onready var mode_buttons: HBoxContainer = $VBoxContainer/ModeButtons

@onready var univers_options: OptionButton = $VBoxContainer/Univers/UniversOptions
@onready var univers_precision: LineEdit = $VBoxContainer/UniversPrecision
@onready var gender_options: OptionButton = $VBoxContainer/Gender/GenderOptions
@onready var age_input: SpinBox = $VBoxContainer/Age/AgeInput
@onready var tarot_check: CheckButton = $VBoxContainer/TarotCheck

const TAROT_PAR_DEFAUT = "Tarot de Marseille"

func _ready() -> void:
	form_container.visible = false


func _on_specificite_pressed() -> void:
	mode_buttons.visible = false
	form_container.visible = true


func _on_custom_start_pressed() -> void:
	GameData.univers_choisi = univers_options.get_item_text(univers_options.selected)
	GameData.precisions = univers_precision.text
	GameData.genre_joueur = gender_options.get_item_text(gender_options.selected)
	GameData.age_joueur = int(age_input.value)
	GameData.type_tarot = TAROT_PAR_DEFAUT
	GameData.tirage_auto = tarot_check.button_pressed

	get_tree().change_scene_to_file("res://scenes/solo_rpg.tscn")


func _on_random_start_pressed() -> void:
	var genres_possibles = ["masculin", "féminin", "neutre"]

	GameData.univers_choisi = ""
	GameData.precisions = ""
	GameData.genre_joueur = genres_possibles[randi() % genres_possibles.size()]
	GameData.age_joueur = randi_range(13, 99)
	GameData.type_tarot = TAROT_PAR_DEFAUT
	GameData.tirage_auto = true

	get_tree().change_scene_to_file("res://scenes/solo_rpg.tscn")
